
# License

OFL

License information can be found here https://github.com/google/fonts/tree/master/ofl/parisienne
